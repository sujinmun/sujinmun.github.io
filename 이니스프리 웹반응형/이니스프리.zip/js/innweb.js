//alert("ok")

function func(js) 
{	
	
	at1.style.display="none";
	at2.style.display="none";
	at3.style.display="none";
	at4.style.display="none";
	at5.style.display="none";
	at7.style.display="none";
	at8.style.display="none";
	at9.style.display="none";
	at10.style.display="none";
	at13.style.display="none";
	at14.style.display="none";
	at15.style.display="none";
	at16.style.display="none";
	
	switch (js) {
		case 1:at1.style.display="block";break;
		case 2:at2.style.display="block";break;
		case 3:at3.style.display="block";break;
		case 4:at4.style.display="block";break;
		case 5:at5.style.display="block";break;
		case 7:at7.style.display="block";break;
		case 8:at8.style.display="block";break;
		case 9:at9.style.display="block";break;
		case 10:at10.style.display="block";break;
		case 13:at13.style.display="block";break;
		case 14:at14.style.display="block";break;
		case 15:at14.style.display="block";break;
		case 16:at16.style.display="block";break;
		case 17:at3.style.display="block";break;
		case 18:at4.style.display="block";break;
		case 19:at3.style.display="block";break;
		case 20:at2.style.display="block";break;
		case 21:at3.style.display="block";break;
		case 22:at7.style.display="block";break;
		case 23:at4.style.display="block";break;
		case 24:at14.style.display="block";break;
		case 25:at14.style.display="block";break;
		case 26:at14.style.display="block";break;
		case 27:at14.style.display="block";break;
	}
}
function func2 (js) 
{
	chat_in.style.display="none";

	
	switch (js) {
		case 1:chat_in.style.display="block";break;

	}
}
function pop_close()
{
	
	chat_in.style.display="none"; 
}





function func3 (js) 
{
	loginbox_bottom1.style.display="none";
	loginbox_bottom2.style.display="none";
	
	switch (js) {
		case 1:loginbox_bottom1.style.display="block";break;
		case 2:loginbox_bottom2.style.display="block";break;
	}
}




function func5 (js) 
{
	at2_2_1.style.display="none";
	at2_2_2.style.display="none";
	at2_2_3.style.display="none";
	at2_2_4.style.display="none";
	at2_2_5.style.display="none";
	
	switch (js) {
		case 1:at2_2_1.style.display="block";break;
		case 2:at2_2_2.style.display="block";break;
		case 3:at2_2_3.style.display="block";break;
		case 4:at2_2_4.style.display="block";break;
		case 5:at2_2_5.style.display="block";break;
	}
}


function func6 (js) 
{	
	at3_2_1.style.display="none";
	at3_2_2.style.display="none";
	at3_2_3.style.display="none";
	at3_2_4.style.display="none";
	at3_2_5.style.display="none";
	
	
	switch (js) {
		case 1:at3_2_1.style.display="block";break;
		case 2:at3_2_2.style.display="block";break;
		case 3:at3_2_3.style.display="block";break;
		case 4:at3_2_4.style.display="block";break;
		case 5:at3_2_5.style.display="block";break;
	}
}	
	function func7 (js) 
{	
	at4_2_1.style.display="none";
	at4_2_2.style.display="none";
	at4_2_3.style.display="none";
	at4_2_4.style.display="none";
	at4_2_5.style.display="none";
	
	
	switch (js) {
		case 1:at4_2_1.style.display="block";break;
		case 2:at4_2_2.style.display="block";break;
		case 3:at4_2_3.style.display="block";break;
		case 4:at4_2_4.style.display="block";break;
		case 5:at4_2_5.style.display="block";break;
	}
}






